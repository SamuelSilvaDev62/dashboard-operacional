import os, io, base64
import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html, Input, Output, State, no_update
import dash_bootstrap_components as dbc
from dash.dash_table import DataTable

def parse_hour(h):
    try:
        return int(str(h).lower().replace('h','').strip())
    except Exception:
        return None

def load_excel(path):
    dfx = pd.read_excel(path, sheet_name='QRY1000')
    dfx.columns = [c.strip() for c in dfx.columns]
    dfx['Hora_num'] = dfx['Hora'].apply(parse_hour)
    return dfx

def df_from_upload(contents):
    content_type, content_string = contents.split(',')
    decoded = base64.b64decode(content_string)
    dfx = pd.read_excel(io.BytesIO(decoded), sheet_name='QRY1000')
    dfx.columns = [c.strip() for c in dfx.columns]
    dfx['Hora_num'] = dfx['Hora'].apply(parse_hour)
    return dfx

def palette(theme):
    if theme == 'dark':
        return {'bg':'#0e1117','card':'#151a22','text':'#e8e8e8','muted':'#a0a0a0',
                'kpi1':'linear-gradient(135deg,#00e3ae,#08b8a2)',
                'kpi2':'linear-gradient(135deg,#4aa8ff,#7b5cff)',
                'kpi3':'linear-gradient(135deg,#ffad66,#ff7a59)',
                'podium':['linear-gradient(135deg,#ffd166,#fca311)','linear-gradient(135deg,#c0c7ff,#6c77ff)','linear-gradient(135deg,#8ce0ff,#36b7ff)'],
                'template':'plotly_dark'}
    return {'bg':'#f7f8fb','card':'#ffffff','text':'#101315','muted':'#6b7280',
            'kpi1':'linear-gradient(135deg,#22d3ee,#38bdf8)',
            'kpi2':'linear-gradient(135deg,#34d399,#10b981)',
            'kpi3':'linear-gradient(135deg,#f59e0b,#f97316)',
            'podium':['linear-gradient(135deg,#fde68a,#f59e0b)','linear-gradient(135deg,#c7d2fe,#6366f1)','linear-gradient(135deg,#bae6fd,#38bdf8)'],
            'template':'plotly_white'}

def kpi_card(title, value, gradient, subtitle=None, icon=None, text_color='#0b0b0b'):
    return dbc.Card(
        dbc.CardBody([
            html.Div([html.Span(icon or '★', style={'fontSize':'22px','marginRight':'8px'}),
                      html.Span(title, style={'fontWeight':600})],
                     style={'display':'flex','alignItems':'center','marginBottom':'6px'}),
            html.Div(f"{value:,}".replace(',', '.'), style={'fontSize':'30px','fontWeight':800}),
            html.Div(subtitle or '', style={'opacity':0.85,'marginTop':'4px'})
        ]),
        style={'background':gradient,'color':text_color,'border':'0','borderRadius':'16px','boxShadow':'0 10px 30px rgba(0,0,0,.15)'}
    )

def top3_cards(by_operador, grads):
    medals = ['🥇','🥈','🥉']
    cards = []
    top3 = by_operador.head(3).reset_index(drop=True)
    for i, row in top3.iterrows():
        cards.append(dbc.Card(dbc.CardBody([
            html.Div([html.Span(medals[i], style={'fontSize':'20px','marginRight':'8px'}),
                      html.Strong(f"{i+1}° — {row['Operador']}")]),
            html.Div(f"{int(row['Qtde. Peças'])} peças", style={'fontSize':'18px','fontWeight':700,'marginTop':'6px'})
        ]), style={'background':grads[i],'color':'#0b0b0b','border':'0','borderRadius':'14px','boxShadow':'0 10px 26px rgba(0,0,0,.20)'}))
    return cards

def make_panel(prefix, title):
    return html.Div([
        dbc.Alert('📁 Clique para importar outro arquivo (.xlsx)', color='secondary', className='mb-2', id=f'alert-{prefix}', style={'opacity':0.9}),
        dcc.Upload(id=f'upload-{prefix}', children=html.Div(['📥 Importar dados (', html.Code(f"{title.replace(' ','_')}.xlsx"), ')']),
                   multiple=False, style={'display':'inline-block','padding':'8px 14px','borderRadius':'10px','border':'1px dashed #9ca3af','cursor':'pointer','marginBottom':'14px'}, accept='.xlsx'),
        dbc.Row([
            dbc.Col(dbc.Card(dbc.CardBody([html.Label('Hora', className='mb-2'),
                                         dbc.Checklist(id=f'horas-{prefix}', options=[], value=[], inline=True)])), md=6),
            dbc.Col(dbc.Card(dbc.CardBody([html.Label('Operador', className='mb-2'),
                                         dcc.Dropdown(id=f'ops-{prefix}', options=[], value=[], multi=True, placeholder='Selecione operadores...', style={'color':'#000','maxWidth':'100%'})])), md=6),
        ], className='g-3 mb-3'),
        dbc.Row([dbc.Col(html.Div(id=f'kpi1-{prefix}'), md=4), dbc.Col(html.Div(id=f'kpi2-{prefix}'), md=4), dbc.Col(html.Div(id=f'kpi3-{prefix}'), md=4)], className='g-3 mb-3'),
        dbc.Row([
            dbc.Col(dbc.Card(dbc.CardBody([html.H5('Peças por Operador', className='mb-2'), dcc.Graph(id=f'g-pecas-{prefix}', config={'displayModeBar': False}, style={'height':'420px'})])), md=7),
            dbc.Col(dbc.Card(dbc.CardBody([html.H5('Pedidos por Operador', className='mb-2'), dcc.Graph(id=f'g-pedidos-{prefix}', config={'displayModeBar': False}, style={'height':'420px'})])), md=5),
        ], className='g-3 mb-3'),
        dbc.Row([
            dbc.Col(dbc.Card(dbc.CardBody([html.H5('Valores por Hora', className='mb-2'), dcc.Graph(id=f'g-hora-{prefix}', config={'displayModeBar': False}, style={'height':'380px'})])), md=8),
            dbc.Col(dbc.Card(dbc.CardBody([html.H5('Top 3 Operadores (Peças)', className='mb-2'), html.Div(id=f'top3-{prefix}', className='d-grid gap-2')])), md=4),
        ], className='g-3 mb-4'),
        dbc.Row([dbc.Col(dbc.Card(dbc.CardBody([html.H5('Tabela — Valores por Hora (Agregado)', className='mb-2'),
            DataTable(id=f'tbl-hora-{prefix}', columns=[{'name': c, 'id': c} for c in ['Hora','Qtde. Peças','Qtde. Pedidos']],
                      style_header={'backgroundColor':'#1b2030','color':'white','border':'0'},
                      style_cell={'backgroundColor':'#12151c','color':'white','border':'0','padding':'10px'},
                      style_table={'overflowX':'auto','overflowY':'auto','maxHeight':'420px'}, sort_action='native') ])), md=12)]),
    ], className='fade')

LOCAL_FAT, LOCAL_SEP = 'Faturamento_Dash.xlsx', 'Separacao_Dash.xlsx'
FALLBACK_FAT, FALLBACK_SEP = '/mnt/data/Faturamento_Dash.xlsx', '/mnt/data/Separacao_Dash.xlsx'
fat_path = LOCAL_FAT if os.path.exists(LOCAL_FAT) else FALLBACK_FAT
sep_path = LOCAL_SEP if os.path.exists(LOCAL_SEP) else (FALLBACK_SEP if os.path.exists(FALLBACK_SEP) else fat_path)
df_fat0, df_sep0 = load_excel(fat_path), load_excel(sep_path)

external_stylesheets = [dbc.themes.LUX]
app = Dash(__name__, external_stylesheets=external_stylesheets)
app.title = 'Dashboard Operacional'
server = app.server

store_fat = dcc.Store(id='data-fat', data=df_fat0.to_dict('records'))
store_sep = dcc.Store(id='data-sep', data=df_sep0.to_dict('records'))
theme_store = dcc.Store(id='theme', data='light')

style_tag = html.Style('.fade{animation:fadein .3s ease-in}@keyframes fadein{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}')
header = dbc.Row([dbc.Col(html.H2('Dashboard Operacional', className='mb-0'), md=8), dbc.Col(html.Div([dbc.Button('🌞', id='theme-toggle', n_clicks=0, outline=True, color='secondary', title='Alternar tema')], className='text-md-end'), md=4)], className='g-2 mb-3')
tabs = dbc.Tabs([dbc.Tab(label='Faturamento', tab_id='fat'), dbc.Tab(label='Separação', tab_id='sep')], id='tabs', active_tab='fat', className='mb-3')
content = html.Div(id='tab-content')

app.layout = html.Div([style_tag, store_fat, store_sep, theme_store, dbc.Container([header, tabs, content], fluid=True, className='py-3', id='root')])

@app.callback(Output('tab-content','children'), Input('tabs','active_tab'))
def render_tab(active):
    return make_panel('fat','Faturamento') if active=='fat' else make_panel('sep','Separação')

@app.callback(Output('data-fat','data'), Output('horas-fat','options'), Output('ops-fat','options'), Output('upload-fat','children'),
              Input('upload-fat','contents'), State('upload-fat','filename'), State('data-fat','data'), prevent_initial_call=True)
def on_upload_fat(contents, filename, current):
    if not contents: return no_update, no_update, no_update, no_update
    try:
        dfx = df_from_upload(contents)
        horas = [{'label': f"{int(h)}h",'value': int(h)} for h in sorted(dfx['Hora_num'].dropna().unique())]
        ops = [{'label': op,'value': op} for op in sorted(dfx['Operador'].dropna().unique())]
        return dfx.to_dict('records'), horas, ops, f'📥 Importado: {filename} (clique para trocar)'
    except Exception as e:
        return current, no_update, no_update, f'❌ Erro: {e}'

@app.callback(Output('data-sep','data'), Output('horas-sep','options'), Output('ops-sep','options'), Output('upload-sep','children'),
              Input('upload-sep','contents'), State('upload-sep','filename'), State('data-sep','data'), prevent_initial_call=True)
def on_upload_sep(contents, filename, current):
    if not contents: return no_update, no_update, no_update, no_update
    try:
        dfx = df_from_upload(contents)
        horas = [{'label': f"{int(h)}h",'value': int(h)} for h in sorted(dfx['Hora_num'].dropna().unique())]
        ops = [{'label': op,'value': op} for op in sorted(dfx['Operador'].dropna().unique())]
        return dfx.to_dict('records'), horas, ops, f'📥 Importado: {filename} (clique para trocar)'
    except Exception as e:
        return current, no_update, no_update, f'❌ Erro: {e}'

@app.callback(Output('theme','data'), Output('theme-toggle','children'), Input('theme-toggle','n_clicks'), State('theme','data'))
def toggle_theme(n, theme):
    if n is None: return theme, ('🌞' if theme=='light' else '🌙')
    new = 'dark' if theme=='light' else 'light'
    return new, ('🌞' if new=='light' else '🌙')

@app.callback(Output('root','style'), Input('theme','data'))
def apply_theme_container(theme):
    p = palette(theme); return {'backgroundColor': p['bg'], 'color': p['text'], 'minHeight': '100vh'}

def register_panel_callbacks(prefix, store_id, kpi_titles):
    @app.callback(
        Output(f'kpi1-{prefix}','children'), Output(f'kpi2-{prefix}','children'), Output(f'kpi3-{prefix}','children'),
        Output(f'g-pecas-{prefix}','figure'), Output(f'g-pedidos-{prefix}','figure'), Output(f'g-hora-{prefix}','figure'),
        Output(f'top3-{prefix}','children'), Output(f'tbl-hora-{prefix}','data'),
        Input(store_id,'data'), Input(f'horas-{prefix}','value'), Input(f'ops-{prefix}','value'), Input('theme','data'),
    )
    def _update(data, horas_sel, ops_sel, theme):
        p = palette(theme)
        dff = pd.DataFrame(data)
        if horas_sel: dff = dff[dff['Hora_num'].isin(horas_sel)]
        if ops_sel: dff = dff[dff['Operador'].isin(ops_sel)]
        total_pecas = int(dff['Qtde. Peças'].sum()) if not dff.empty else 0
        total_pedidos = int(dff['Qtde. Pedidos'].sum()) if not dff.empty else 0
        operadores = int(dff['Operador'].nunique()) if not dff.empty else 0
        k1 = kpi_card(kpi_titles[0], total_pecas, p.get('kpi1','#eee'), 'Acumulado no filtro', '📦')
        k2 = kpi_card(kpi_titles[1], total_pedidos, p.get('kpi2','#ddd'), 'Acumulado no filtro', '🧾')
        k3 = kpi_card(kpi_titles[2], operadores, p.get('kpi3','#ccc'), 'Com movimentação', '👤')
        by_op = dff.groupby('Operador', as_index=False)[['Qtde. Peças','Qtde. Pedidos']].sum().sort_values('Qtde. Peças', ascending=False)
        by_hr = dff.groupby('Hora_num', as_index=False)[['Qtde. Peças','Qtde. Pedidos']].sum().sort_values('Hora_num')
        by_hr['Hora'] = by_hr['Hora_num'].apply(lambda x: f"{int(x)}h" if pd.notnull(x) else '')
        fig1 = px.bar(by_op, y='Operador', x='Qtde. Peças', orientation='h', text='Qtde. Peças', color='Qtde. Peças',
                      color_continuous_scale=['#34d399','#06b6d4','#60a5fa','#a78bfa','#fb7185'], template=p['template'])
        fig1.update_traces(textposition='outside', cliponaxis=False, marker_line_width=0)
        fig1.update_layout(margin=dict(l=10,r=10,t=10,b=10), coloraxis_showscale=False, xaxis_title='Peças', yaxis_title='', yaxis=dict(autorange='reversed'))
        fig2 = px.bar(by_op, x='Operador', y='Qtde. Pedidos', text='Qtde. Pedidos', color='Qtde. Pedidos',
                      color_continuous_scale=['#22d3ee','#60a5fa','#7c3aed','#f472b6'], template=p['template'])
        fig2.update_traces(textposition='outside', marker_line_width=0)
        fig2.update_layout(margin=dict(l=10,r=10,t=10,b=10), coloraxis_showscale=False, xaxis_title='', yaxis_title='Pedidos', xaxis=dict(tickangle=-30))
        fig3 = px.line(by_hr, x='Hora', y='Qtde. Peças', markers=True, template=p['template'])
        fig3.add_bar(x=by_hr['Hora'], y=by_hr['Qtde. Pedidos'], name='Pedidos', opacity=0.35)
        fig3.update_traces(marker=dict(size=8), selector=dict(mode='lines+markers'))
        fig3.update_layout(margin=dict(l=10,r=10,t=10,b=10), yaxis_title='Volume', legend_title='')
        top3 = top3_cards(by_op, p['podium']) if len(by_op)>0 else []
        tbl = by_hr[['Hora','Qtde. Peças','Qtde. Pedidos']].to_dict('records')
        return k1, k2, k3, fig1, fig2, fig3, top3, tbl

register_panel_callbacks('fat','data-fat',['Peças Faturadas','Pedidos Faturados','Operadores de Faturamento'])
register_panel_callbacks('sep','data-sep',['Peças Separadas','Pedidos Separados','Operadores de Separação'])

if __name__ == '__main__':
    app.run(debug=True)
